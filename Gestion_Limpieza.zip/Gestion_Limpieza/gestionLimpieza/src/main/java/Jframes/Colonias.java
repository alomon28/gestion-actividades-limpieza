
package Jframes;

import DB.connection;
import java.awt.Color;
import java.awt.Font;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

public class Colonias extends javax.swing.JFrame {


    public Colonias() {
        initComponents();
        cargarTablaColonias(); // 🔹 Cargar colonias al iniciar
        setLocationRelativeTo(null);
        
        
        // 🎨 Color base y estilo de botones AWT
        Color azulPrincipal = new Color(0, 102, 204);
        Font fuenteBoton = new Font("Segoe UI", Font.BOLD, 13);

        // --- Botones tipo java.awt.Button ---
        buttonActividades.setBackground(azulPrincipal);
        buttonActividades.setForeground(Color.WHITE);
        buttonActividades.setFont(fuenteBoton);

        buttonBuscar.setBackground(azulPrincipal);
        buttonBuscar.setForeground(Color.WHITE);
        buttonBuscar.setFont(fuenteBoton);

        buttonColonias.setBackground(azulPrincipal);
        buttonColonias.setForeground(Color.WHITE);
        buttonColonias.setFont(fuenteBoton);

        buttonCuadrillas.setBackground(azulPrincipal);
        buttonCuadrillas.setForeground(Color.WHITE);
        buttonCuadrillas.setFont(fuenteBoton);

        buttonDashboard.setBackground(azulPrincipal);
        buttonDashboard.setForeground(Color.WHITE);
        buttonDashboard.setFont(fuenteBoton);

        buttonEditar.setBackground(azulPrincipal);
        buttonEditar.setForeground(Color.WHITE);
        buttonEditar.setFont(fuenteBoton);

        buttonEliminar.setBackground(azulPrincipal);
        buttonEliminar.setForeground(Color.WHITE);
        buttonEliminar.setFont(fuenteBoton);

        buttonGuardar.setBackground(azulPrincipal);
        buttonGuardar.setForeground(Color.WHITE);
        buttonGuardar.setFont(fuenteBoton);

        buttonNuevo.setBackground(azulPrincipal);
        buttonNuevo.setForeground(Color.WHITE);
        buttonNuevo.setFont(fuenteBoton);

        // --- Botones tipo javax.swing.JButton ---
        jButtonMenu.setBackground(azulPrincipal);
        jButtonMenu.setForeground(Color.WHITE);
        jButtonMenu.setFont(fuenteBoton);
        jButtonMenu.setFocusPainted(false);
        jButtonMenu.setBorderPainted(false);


    }
    
    private void cargarTablaColonias() {
        DefaultTableModel modelo = new DefaultTableModel();
        modelo.addColumn("ID");
        modelo.addColumn("Nombre");
        modelo.addColumn("Código Postal");
        tabla.setModel(modelo);

        try {
            connection conecta = new connection();
            Connection con = conecta.getConexion();
            String sql = "SELECT * FROM Colonia";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Object[] fila = new Object[3];
                fila[0] = rs.getInt("idColonia");
                fila[1] = rs.getString("nombre");
                fila[2] = rs.getString("codigoPostal");
                modelo.addRow(fila);
            }
            tabla.setModel(modelo);
            rs.close();
            ps.close();
            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "❌ Error al cargar tabla: " + e.getMessage());
        }
    }
    @SuppressWarnings("unchecked")  
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel3 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tabla = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jButtonMenu = new javax.swing.JButton();
        buttonActividades = new java.awt.Button();
        buttonColonias = new java.awt.Button();
        buttonDashboard = new java.awt.Button();
        buttonCuadrillas = new java.awt.Button();
        boxColonia = new javax.swing.JTextField();
        boxNombreColonia = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        boxCodigoPostal = new javax.swing.JTextField();
        label1 = new java.awt.Label();
        buttonBuscar = new java.awt.Button();
        buttonNuevo = new java.awt.Button();
        buttonGuardar = new java.awt.Button();
        buttonEditar = new java.awt.Button();
        buttonEliminar = new java.awt.Button();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setText("Colonia:");

        tabla.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ));
        jScrollPane1.setViewportView(tabla);

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("Tabla de Colonias");

        jButtonMenu.setBackground(javax.swing.UIManager.getDefaults().getColor("Actions.Blue"));
        jButtonMenu.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButtonMenu.setForeground(new java.awt.Color(255, 255, 255));
        jButtonMenu.setText("Menu");
        jButtonMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonMenuActionPerformed(evt);
            }
        });

        buttonActividades.setBackground(javax.swing.UIManager.getDefaults().getColor("CheckBoxMenuItem.selectionBackground"));
        buttonActividades.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        buttonActividades.setForeground(new java.awt.Color(255, 255, 255));
        buttonActividades.setLabel("Actividades");
        buttonActividades.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonActividadesActionPerformed(evt);
            }
        });

        buttonColonias.setBackground(javax.swing.UIManager.getDefaults().getColor("PropSheet.selectionBackground"));
        buttonColonias.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        buttonColonias.setForeground(new java.awt.Color(255, 255, 255));
        buttonColonias.setLabel("Colonias");
        buttonColonias.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonColoniasActionPerformed(evt);
            }
        });

        buttonDashboard.setBackground(javax.swing.UIManager.getDefaults().getColor("nb.html.link.foreground.hover"));
        buttonDashboard.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        buttonDashboard.setForeground(new java.awt.Color(255, 255, 255));
        buttonDashboard.setLabel("Dashboard");
        buttonDashboard.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonDashboardActionPerformed(evt);
            }
        });

        buttonCuadrillas.setBackground(javax.swing.UIManager.getDefaults().getColor("CheckBox.icon[filled].focusedSelectedBackground"));
        buttonCuadrillas.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        buttonCuadrillas.setForeground(new java.awt.Color(255, 255, 255));
        buttonCuadrillas.setLabel("Cuadrillas");
        buttonCuadrillas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonCuadrillasActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(buttonCuadrillas, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(buttonActividades, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(buttonColonias, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(buttonDashboard, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButtonMenu, javax.swing.GroupLayout.DEFAULT_SIZE, 129, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(buttonActividades, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(buttonColonias, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(buttonDashboard, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(buttonCuadrillas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jButtonMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        boxColonia.setText("\"NO LLENAR ESTA PARTE\"");

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("Nombre de Colonia:");

        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("Codigo Postal:");

        label1.setBackground(javax.swing.UIManager.getDefaults().getColor("CheckBox.icon[filled].pressedSelectedBackground"));
        label1.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        label1.setForeground(new java.awt.Color(255, 255, 255));
        label1.setText("                                          Gestión de Actividades de Limpieza ");

        buttonBuscar.setBackground(new java.awt.Color(255, 153, 0));
        buttonBuscar.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        buttonBuscar.setForeground(new java.awt.Color(255, 255, 255));
        buttonBuscar.setLabel("Buscar");
        buttonBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonBuscarActionPerformed(evt);
            }
        });

        buttonNuevo.setBackground(javax.swing.UIManager.getDefaults().getColor("CheckBox.icon[filled].hoverSelectedBackground"));
        buttonNuevo.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        buttonNuevo.setForeground(new java.awt.Color(255, 255, 255));
        buttonNuevo.setLabel("Nuevo");
        buttonNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonNuevoActionPerformed(evt);
            }
        });

        buttonGuardar.setBackground(javax.swing.UIManager.getDefaults().getColor("CheckBoxMenuItem.selectionBackground"));
        buttonGuardar.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        buttonGuardar.setForeground(new java.awt.Color(255, 255, 255));
        buttonGuardar.setLabel("Guardar");
        buttonGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonGuardarActionPerformed(evt);
            }
        });

        buttonEditar.setBackground(javax.swing.UIManager.getDefaults().getColor("PropSheet.selectionBackground"));
        buttonEditar.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        buttonEditar.setForeground(new java.awt.Color(255, 255, 255));
        buttonEditar.setLabel("Editar");
        buttonEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonEditarActionPerformed(evt);
            }
        });

        buttonEliminar.setBackground(javax.swing.UIManager.getDefaults().getColor("nb.html.link.foreground.hover"));
        buttonEliminar.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        buttonEliminar.setForeground(new java.awt.Color(255, 255, 255));
        buttonEliminar.setLabel("Eliminar");
        buttonEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonEliminarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(label1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3))
                .addGap(38, 38, 38)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(boxNombreColonia, javax.swing.GroupLayout.DEFAULT_SIZE, 212, Short.MAX_VALUE)
                    .addComponent(boxColonia, javax.swing.GroupLayout.DEFAULT_SIZE, 212, Short.MAX_VALUE)
                    .addComponent(boxCodigoPostal))
                .addGap(57, 57, 57)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 317, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 44, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4))
                .addGap(127, 127, 127))
            .addGroup(layout.createSequentialGroup()
                .addGap(91, 91, 91)
                .addComponent(buttonEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addComponent(buttonNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(33, 33, 33)
                .addComponent(buttonGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(44, 44, 44)
                .addComponent(buttonEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(buttonBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(label1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22)
                .addComponent(jLabel4)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 267, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 75, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(buttonEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(buttonBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(buttonGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(buttonNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(buttonEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(42, 42, 42)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(boxColonia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel3))
                        .addGap(53, 53, 53)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(boxNombreColonia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addGap(54, 54, 54)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(boxCodigoPostal, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void limpiar(){
        boxColonia.setText("");
        boxNombreColonia.setText("");
        boxCodigoPostal.setText("");
    }
    private void buttonNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonNuevoActionPerformed
        // TODO add your handling code here:
        boxColonia.setText("");
        boxNombreColonia.setText("");
        boxCodigoPostal.setText("");
    }//GEN-LAST:event_buttonNuevoActionPerformed

    private void jButtonMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonMenuActionPerformed
        // TODO add your handling code here:
        Menu_principal m = new Menu_principal();
        m.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButtonMenuActionPerformed

    private void buttonActividadesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonActividadesActionPerformed
        // TODO add your handling code here:
        Actividades a = new Actividades();
        a.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_buttonActividadesActionPerformed

    private void buttonColoniasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonColoniasActionPerformed
        // TODO add your handling code here:
        Colonias c = new Colonias();
        c.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_buttonColoniasActionPerformed

    private void buttonDashboardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonDashboardActionPerformed
        // TODO add your handling code here:
        Dashboard d = new Dashboard();
        d.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_buttonDashboardActionPerformed

    private void buttonCuadrillasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonCuadrillasActionPerformed
        Cuadrillas c = new Cuadrillas();
        c.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_buttonCuadrillasActionPerformed

    private void buttonEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonEliminarActionPerformed
        // TODO add your handling code here:
        String id = boxColonia.getText().trim();

        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(this, "⚠️ Ingresa el ID de la colonia a eliminar");
            return;
        }

        try {
            connection conecta = new connection();
            Connection con = conecta.getConexion();
            String sql = "DELETE FROM Colonia WHERE idColonia=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, Integer.parseInt(id));
            int rows = ps.executeUpdate();

            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "✅ Colonia eliminada correctamente");
            } else {
                JOptionPane.showMessageDialog(this, "⚠️ No se encontró la colonia con ese ID");
            }

            ps.close();
            con.close();
            limpiar();
            cargarTablaColonias();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "❌ Error al eliminar: " + e.getMessage());
        }
    }//GEN-LAST:event_buttonEliminarActionPerformed

    private void buttonGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonGuardarActionPerformed
        String nombre = boxNombreColonia.getText().trim();
        String codigoPostal = boxCodigoPostal.getText().trim();

        if (nombre.isEmpty() || codigoPostal.isEmpty()) {
            JOptionPane.showMessageDialog(this, "⚠️ Todos los campos deben estar llenos");
            return;
        }

        try {
            connection conecta = new connection();
            Connection con = conecta.getConexion();
            String sql = "INSERT INTO Colonia(nombre, codigoPostal) VALUES (?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, nombre);
            ps.setString(2, codigoPostal);
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "✅ Colonia registrada correctamente");
            ps.close();
            con.close();
            limpiar();
            cargarTablaColonias();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "❌ Error al guardar: " + e.getMessage());
        }
    }//GEN-LAST:event_buttonGuardarActionPerformed

    private void buttonEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonEditarActionPerformed
        // TODO add your handling code here:
        String id = boxColonia.getText().trim();
        String nombre = boxNombreColonia.getText().trim();
        String codigoPostal = boxCodigoPostal.getText().trim();

        if (id.isEmpty() || nombre.isEmpty() || codigoPostal.isEmpty()) {
            JOptionPane.showMessageDialog(this, "⚠️ Todos los campos deben estar llenos");
            return;
        }

        try {
            connection conecta = new connection();
            Connection con = conecta.getConexion();
            String sql = "UPDATE Colonia SET nombre=?, codigoPostal=? WHERE idColonia=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, nombre);
            ps.setString(2, codigoPostal);
            ps.setInt(3, Integer.parseInt(id));
            int rows = ps.executeUpdate();

            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "✅ Colonia actualizada correctamente");
            } else {
                JOptionPane.showMessageDialog(this, "⚠️ No se encontró la colonia con ese ID");
            }

            ps.close();
            con.close();
            limpiar();
            cargarTablaColonias();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "❌ Error al editar: " + e.getMessage());
        }
    }//GEN-LAST:event_buttonEditarActionPerformed

    private void buttonBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonBuscarActionPerformed
       String id = boxColonia.getText().trim();

        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(this, "⚠️ Ingresa el ID de la colonia a buscar");
            return;
        }

        try {
            connection conecta = new connection();
            Connection con = conecta.getConexion();
            String sql = "SELECT * FROM Colonia WHERE idColonia=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, Integer.parseInt(id));
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                boxNombreColonia.setText(rs.getString("nombre"));
                boxCodigoPostal.setText(rs.getString("codigoPostal"));
            } else {
                JOptionPane.showMessageDialog(this, "❌ No se encontró la colonia");
                limpiar();
            }

            rs.close();
            ps.close();
            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "❌ Error al buscar: " + e.getMessage());
        }
    }//GEN-LAST:event_buttonBuscarActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Colonias.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Colonias.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Colonias.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Colonias.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Colonias().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField boxCodigoPostal;
    private javax.swing.JTextField boxColonia;
    private javax.swing.JTextField boxNombreColonia;
    private java.awt.Button buttonActividades;
    private java.awt.Button buttonBuscar;
    private java.awt.Button buttonColonias;
    private java.awt.Button buttonCuadrillas;
    private java.awt.Button buttonDashboard;
    private java.awt.Button buttonEditar;
    private java.awt.Button buttonEliminar;
    private java.awt.Button buttonGuardar;
    private java.awt.Button buttonNuevo;
    private javax.swing.JButton jButtonMenu;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JScrollPane jScrollPane1;
    private java.awt.Label label1;
    private javax.swing.JTable tabla;
    // End of variables declaration//GEN-END:variables
}
