
package Jframes;
import java.awt.Image;
import java.io.File;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import javax.swing.ImageIcon;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import DB.connection;
import DB.connection;
import java.awt.Color;
import java.awt.Font;
import java.sql.ResultSet;
import javax.swing.filechooser.FileNameExtensionFilter;

public class Actividades extends javax.swing.JFrame {

    public Actividades() {
        initComponents();
        llenarCombos();
        


        // 🎨 Color base y estilo de botones AWT
        Color azulPrincipal = new Color(0, 102, 204);
        Font fuenteBoton = new Font("Segoe UI", Font.BOLD, 13);

        // --- Botones tipo java.awt.Button ---
        buttonActividades.setBackground(azulPrincipal);
        buttonActividades.setForeground(Color.WHITE);
        buttonActividades.setFont(fuenteBoton);

        buttonBuscar.setBackground(azulPrincipal);
        buttonBuscar.setForeground(Color.WHITE);
        buttonBuscar.setFont(fuenteBoton);

        buttonColonias.setBackground(azulPrincipal);
        buttonColonias.setForeground(Color.WHITE);
        buttonColonias.setFont(fuenteBoton);

        buttonCuadrillas.setBackground(azulPrincipal);
        buttonCuadrillas.setForeground(Color.WHITE);
        buttonCuadrillas.setFont(fuenteBoton);

        buttonDashboard.setBackground(azulPrincipal);
        buttonDashboard.setForeground(Color.WHITE);
        buttonDashboard.setFont(fuenteBoton);

        buttonEditar.setBackground(azulPrincipal);
        buttonEditar.setForeground(Color.WHITE);
        buttonEditar.setFont(fuenteBoton);

        buttonEliminar.setBackground(azulPrincipal);
        buttonEliminar.setForeground(Color.WHITE);
        buttonEliminar.setFont(fuenteBoton);

        buttonGuardar.setBackground(azulPrincipal);
        buttonGuardar.setForeground(Color.WHITE);
        buttonGuardar.setFont(fuenteBoton);

        buttonNuevo.setBackground(azulPrincipal);
        buttonNuevo.setForeground(Color.WHITE);
        buttonNuevo.setFont(fuenteBoton);

        // --- Botones tipo javax.swing.JButton ---
        jButtonMenu.setBackground(azulPrincipal);
        jButtonMenu.setForeground(Color.WHITE);
        jButtonMenu.setFont(fuenteBoton);
        jButtonMenu.setFocusPainted(false);
        jButtonMenu.setBorderPainted(false);

        jButtonSubirImagen.setBackground(azulPrincipal);
        jButtonSubirImagen.setForeground(Color.WHITE);
        jButtonSubirImagen.setFont(fuenteBoton);
        jButtonSubirImagen.setFocusPainted(false);
        jButtonSubirImagen.setBorderPainted(false);
    }
    
    private void llenarCombos() {
    try (Connection con = new connection().getConexion()) {
        PreparedStatement ps;
        ResultSet rs;

        // Combo Cuadrillas
        comboCuadrillaAsignada.removeAllItems();
        ps = con.prepareStatement("SELECT idCuadrilla, nombre FROM Cuadrilla");
        rs = ps.executeQuery();
        while (rs.next()) {
            comboCuadrillaAsignada.addItem(rs.getInt("idCuadrilla") + " - " + rs.getString("nombre"));
        }

        // Combo Colonias
        boxColonia.removeAllItems();
        ps = con.prepareStatement("SELECT idColonia, nombre FROM Colonia");
        rs = ps.executeQuery();
        while (rs.next()) {
            boxColonia.addItem(rs.getInt("idColonia") + " - " + rs.getString("nombre"));
        }

    } catch (SQLException e) {
        JOptionPane.showMessageDialog(this, "Error al llenar combos: " + e.getMessage());
    }
}

    
    

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        label1 = new java.awt.Label();
        jLabel2 = new javax.swing.JLabel();
        label2 = new java.awt.Label();
        jLabel3 = new javax.swing.JLabel();
        buttonNuevo = new java.awt.Button();
        jLabel4 = new javax.swing.JLabel();
        buttonGuardar = new java.awt.Button();
        jLabel5 = new javax.swing.JLabel();
        buttonEditar = new java.awt.Button();
        boxColonia = new javax.swing.JComboBox<>();
        buttonEliminar = new java.awt.Button();
        boxFecha = new javax.swing.JTextField();
        buttonBuscar = new java.awt.Button();
        boxIdActividad = new javax.swing.JTextField();
        jButtonSubirImagen = new javax.swing.JButton();
        boxDescripcion = new javax.swing.JTextField();
        lblImagen = new javax.swing.JLabel();
        comboCuadrillaAsignada = new javax.swing.JComboBox<>();
        jPanel3 = new javax.swing.JPanel();
        buttonActividades = new java.awt.Button();
        buttonColonias = new java.awt.Button();
        buttonDashboard = new java.awt.Button();
        buttonCuadrillas = new java.awt.Button();
        jButtonMenu = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jLabel1.setBackground(new java.awt.Color(255, 255, 255));
        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel1.setText("ID Actividad (auto)");

        label1.setBackground(javax.swing.UIManager.getDefaults().getColor("CheckBox.icon[filled].pressedSelectedBackground"));
        label1.setFont(new java.awt.Font("Arial Black", 0, 18)); // NOI18N
        label1.setForeground(new java.awt.Color(255, 255, 255));
        label1.setText("                                  Gestión de Actividades de Limpieza ");

        jLabel2.setBackground(new java.awt.Color(255, 255, 255));
        jLabel2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel2.setText("Descripción");

        label2.setBackground(java.awt.Color.orange);
        label2.setFont(new java.awt.Font("Franklin Gothic Medium", 0, 18)); // NOI18N
        label2.setForeground(new java.awt.Color(255, 255, 255));
        label2.setText("Registrar actividades de limpieza realizadas");

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel3.setText("Fecha");

        buttonNuevo.setBackground(javax.swing.UIManager.getDefaults().getColor("CheckBox.icon[filled].hoverSelectedBackground"));
        buttonNuevo.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        buttonNuevo.setForeground(new java.awt.Color(255, 255, 255));
        buttonNuevo.setLabel("Nuevo");
        buttonNuevo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonNuevoActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel4.setText("Cuadrilla asignada");

        buttonGuardar.setBackground(javax.swing.UIManager.getDefaults().getColor("CheckBoxMenuItem.selectionBackground"));
        buttonGuardar.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        buttonGuardar.setForeground(new java.awt.Color(255, 255, 255));
        buttonGuardar.setLabel("Guardar");
        buttonGuardar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonGuardarActionPerformed(evt);
            }
        });

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jLabel5.setText("Colonia");

        buttonEditar.setBackground(javax.swing.UIManager.getDefaults().getColor("PropSheet.selectionBackground"));
        buttonEditar.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        buttonEditar.setForeground(new java.awt.Color(255, 255, 255));
        buttonEditar.setLabel("Editar");
        buttonEditar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonEditarActionPerformed(evt);
            }
        });

        boxColonia.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        boxColonia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                boxColoniaActionPerformed(evt);
            }
        });

        buttonEliminar.setBackground(javax.swing.UIManager.getDefaults().getColor("nb.html.link.foreground.hover"));
        buttonEliminar.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        buttonEliminar.setForeground(new java.awt.Color(255, 255, 255));
        buttonEliminar.setLabel("Eliminar");
        buttonEliminar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonEliminarActionPerformed(evt);
            }
        });

        buttonBuscar.setBackground(new java.awt.Color(255, 153, 0));
        buttonBuscar.setFont(new java.awt.Font("Dialog", 1, 18)); // NOI18N
        buttonBuscar.setForeground(new java.awt.Color(255, 255, 255));
        buttonBuscar.setLabel("Buscar");
        buttonBuscar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonBuscarActionPerformed(evt);
            }
        });

        jButtonSubirImagen.setText("Subir Imagen");
        jButtonSubirImagen.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonSubirImagenActionPerformed(evt);
            }
        });

        comboCuadrillaAsignada.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        comboCuadrillaAsignada.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboCuadrillaAsignadaActionPerformed(evt);
            }
        });

        buttonActividades.setBackground(javax.swing.UIManager.getDefaults().getColor("CheckBoxMenuItem.selectionBackground"));
        buttonActividades.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        buttonActividades.setForeground(new java.awt.Color(255, 255, 255));
        buttonActividades.setLabel("Actividades");
        buttonActividades.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonActividadesActionPerformed(evt);
            }
        });

        buttonColonias.setBackground(javax.swing.UIManager.getDefaults().getColor("PropSheet.selectionBackground"));
        buttonColonias.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        buttonColonias.setForeground(new java.awt.Color(255, 255, 255));
        buttonColonias.setLabel("Colonias");
        buttonColonias.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonColoniasActionPerformed(evt);
            }
        });

        buttonDashboard.setBackground(javax.swing.UIManager.getDefaults().getColor("nb.html.link.foreground.hover"));
        buttonDashboard.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        buttonDashboard.setForeground(new java.awt.Color(255, 255, 255));
        buttonDashboard.setLabel("Dashboard");
        buttonDashboard.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonDashboardActionPerformed(evt);
            }
        });

        buttonCuadrillas.setBackground(javax.swing.UIManager.getDefaults().getColor("CheckBox.icon[filled].focusedSelectedBackground"));
        buttonCuadrillas.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        buttonCuadrillas.setForeground(new java.awt.Color(255, 255, 255));
        buttonCuadrillas.setLabel("Cuadrillas");
        buttonCuadrillas.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                buttonCuadrillasActionPerformed(evt);
            }
        });

        jButtonMenu.setBackground(javax.swing.UIManager.getDefaults().getColor("Actions.Blue"));
        jButtonMenu.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        jButtonMenu.setForeground(new java.awt.Color(255, 255, 255));
        jButtonMenu.setText("Menu");
        jButtonMenu.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButtonMenuActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(buttonCuadrillas, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(buttonActividades, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(buttonColonias, javax.swing.GroupLayout.PREFERRED_SIZE, 83, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(buttonDashboard, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jButtonMenu, javax.swing.GroupLayout.DEFAULT_SIZE, 129, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(buttonActividades, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(buttonColonias, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(buttonDashboard, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(buttonCuadrillas, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(jButtonMenu, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(label1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(26, 26, 26)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(buttonEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(27, 27, 27)
                                .addComponent(buttonNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(33, 33, 33)
                                .addComponent(buttonGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(33, 33, 33)
                                .addComponent(buttonEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(29, 29, 29)
                                .addComponent(buttonBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 103, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(jLabel4)
                                            .addComponent(jLabel5)
                                            .addComponent(jLabel2)
                                            .addComponent(jLabel3))
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(boxColonia, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(comboCuadrillaAsignada, javax.swing.GroupLayout.PREFERRED_SIZE, 193, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addGroup(layout.createSequentialGroup()
                                                .addGap(288, 288, 288)
                                                .addComponent(jButtonSubirImagen, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                    .addGroup(layout.createSequentialGroup()
                                        .addComponent(jLabel1)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(boxDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(boxFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 124, javax.swing.GroupLayout.PREFERRED_SIZE)
                                            .addComponent(boxIdActividad, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblImagen, javax.swing.GroupLayout.PREFERRED_SIZE, 289, javax.swing.GroupLayout.PREFERRED_SIZE))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(99, 99, 99)
                        .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(241, 241, 241)
                        .addComponent(label2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(10, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(label1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(9, 9, 9)
                .addComponent(label2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(boxIdActividad, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel1))
                        .addGap(31, 31, 31)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(boxDescripcion, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel2))
                        .addGap(35, 35, 35)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel3)
                            .addComponent(boxFecha, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(32, 32, 32)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel4)
                                    .addComponent(comboCuadrillaAsignada, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGap(36, 36, 36)
                                .addComponent(jLabel5))
                            .addComponent(boxColonia, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                    .addComponent(lblImagen, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(jButtonSubirImagen, javax.swing.GroupLayout.PREFERRED_SIZE, 32, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(buttonEditar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(buttonBuscar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(buttonGuardar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(buttonNuevo, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(buttonEliminar, javax.swing.GroupLayout.PREFERRED_SIZE, 36, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(197, 197, 197))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void buttonNuevoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonNuevoActionPerformed
        boxIdActividad.setText("");
        boxDescripcion.setText("");
        boxFecha.setText("");
        comboCuadrillaAsignada.setSelectedIndex(-1);
        boxColonia.setSelectedIndex(-1);
        lblImagen.setText("");       
        lblImagen.setIcon(null);

    }//GEN-LAST:event_buttonNuevoActionPerformed

    private void buttonCuadrillasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonCuadrillasActionPerformed
        Cuadrillas c = new Cuadrillas();
        c.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_buttonCuadrillasActionPerformed

    private void buttonActividadesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonActividadesActionPerformed
        // TODO add your handling code here:
        Actividades a = new Actividades();
        a.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_buttonActividadesActionPerformed

    private void buttonColoniasActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonColoniasActionPerformed
        // TODO add your handling code here:
        Colonias c = new Colonias();
        c.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_buttonColoniasActionPerformed

    private void buttonDashboardActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonDashboardActionPerformed
        // TODO add your handling code here:
        Dashboard d = new Dashboard();
        d.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_buttonDashboardActionPerformed

    private void jButtonMenuActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonMenuActionPerformed
        // TODO add your handling code here:
        Menu_principal m = new Menu_principal();
        m.setVisible(true);
        this.dispose();
    }//GEN-LAST:event_jButtonMenuActionPerformed

    private void buttonEliminarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonEliminarActionPerformed
        connection conecta = new connection();
        Connection con = conecta.getConexion();
        PreparedStatement ps = null;
        
        try {
            if (con == null) {
                JOptionPane.showMessageDialog(null, "❌ Error de conexión con la base de datos");
                return;
            }

            String id = boxIdActividad.getText();

            if (id.isEmpty()) {
                JOptionPane.showMessageDialog(this, "⚠️ Ingresa el ID de la actividad que deseas eliminar.");
                return;
            }

            int confirm = JOptionPane.showConfirmDialog(this,
                    "¿Seguro que deseas eliminar esta actividad: " + id + "?",
                    "Confirmar eliminación", JOptionPane.YES_NO_OPTION);

            if (confirm != JOptionPane.YES_OPTION) {
                return;
            }

            String sql = "DELETE FROM Actividad WHERE idActividad = ?";
            ps = con.prepareStatement(sql);
            ps.setString(1, id);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "🗑️ Actividad eliminado correctamente.");
                // Limpia los campos
                boxIdActividad.setText("");
                boxDescripcion.setText("");
                boxFecha.setText("");
                comboCuadrillaAsignada.setSelectedIndex(-1);
                boxColonia.setSelectedIndex(-1);
                lblImagen.setText("");
            } else {
                JOptionPane.showMessageDialog(this, "⚠️ No se encontró ningúna actividad con ese id.");
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "❌ Error al eliminar: " + e.getMessage());
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }

    
        
    }//GEN-LAST:event_buttonEliminarActionPerformed

    private void buttonGuardarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonGuardarActionPerformed
        connection conecta = new connection();
        Connection con = conecta.getConexion();
        PreparedStatement ps = null;

        try {
            if (con == null) {
                JOptionPane.showMessageDialog(null, "❌ Error de conexión con la base de datos");
                return;
            }

            // Obtener valores de los campos
            String idActividadTexto = boxIdActividad.getText();
            String descripcion = boxDescripcion.getText();
            String fechaTexto = boxFecha.getText();
            String cuadrillaSeleccionada = (String) comboCuadrillaAsignada.getSelectedItem();
            String coloniaSeleccionada = (String) boxColonia.getSelectedItem();
            String imagen = lblImagen.getText();

            // Validar campos
            if (idActividadTexto.isEmpty() || descripcion.isEmpty() || fechaTexto.isEmpty()
                    || cuadrillaSeleccionada == null || coloniaSeleccionada == null) {
                JOptionPane.showMessageDialog(this, "⚠️ Todos los campos deben estar llenos.");
                return;
            }

            // Convertir idActividad a entero
            int idActividad = Integer.parseInt(idActividadTexto);

            // Obtener ID de cuadrilla y colonia (tomando antes del " - ")
            int idCuadrilla = Integer.parseInt(cuadrillaSeleccionada.split(" - ")[0]);
            int idColonia = Integer.parseInt(coloniaSeleccionada.split(" - ")[0]);

            // Convertir fecha a formato MySQL DATE (YYYY-MM-DD)
            java.sql.Date fechaSQL = null;
            try {
                fechaSQL = parseFecha(fechaTexto);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "⚠️ Formato de fecha inválido. Usa dd.MM.yyyy, dd/MM/yyyy o yyyy-MM-dd.");
                return;
            }

            // Sentencia SQL
            String sql = "INSERT INTO Actividad (idActividad, descripcion, fecha, idCuadrilla, idColonia, evidencia) VALUES (?, ?, ?, ?, ?, ?)";
            ps = con.prepareStatement(sql);

            // Asignar parámetros
            ps.setInt(1, idActividad);
            ps.setString(2, descripcion);
            ps.setDate(3, fechaSQL);
            ps.setInt(4, idCuadrilla);
            ps.setInt(5, idColonia);
            ps.setString(6, imagen);

            // Ejecutar
            ps.executeUpdate();
            JOptionPane.showMessageDialog(this, "✅ Actividad registrada correctamente");

            // Limpiar campos
            boxIdActividad.setText("");
            boxDescripcion.setText("");
            boxFecha.setText("");
            comboCuadrillaAsignada.setSelectedIndex(-1);
            boxColonia.setSelectedIndex(-1);
            lblImagen.setText("");
            lblImagen.setIcon(null);

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "⚠️ Error: verifica que los campos numéricos (ID, Cuadrilla, Colonia) sean válidos.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "❌ Error al registrar: " + e.getMessage());
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "⚠️ Error al cerrar conexión: " + e.getMessage());
            }
        }
    }//GEN-LAST:event_buttonGuardarActionPerformed
  
    private java.sql.Date parseFecha(String fechaTexto) throws Exception {
        String[] formatos = {"dd.MM.yyyy", "dd/MM/yyyy", "yyyy-MM-dd"};
        java.util.Date fecha = null;
        for (String f : formatos) {
            try {
                fecha = new java.text.SimpleDateFormat(f).parse(fechaTexto);
                break; // si parsea correctamente, salir del loop
            } catch (Exception e) {
                // intentar con el siguiente formato
            }
        }
        if (fecha == null) {
            throw new Exception("Formato inválido");
        }
        return new java.sql.Date(fecha.getTime());
    }
    private void buttonBuscarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonBuscarActionPerformed
        Connection con = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            // Conexión
            connection conecta = new connection();
            con = conecta.getConexion();

            String idActividad = boxIdActividad.getText().trim();

            if (idActividad.isEmpty()) {
                JOptionPane.showMessageDialog(null, "⚠️ Ingresa un ID de actividad válido.");
                return;
            }

            String sql = "SELECT descripcion, fecha, idCuadrilla, idColonia, evidencia FROM Actividad WHERE idActividad = ?";
            ps = con.prepareStatement(sql);
            ps.setString(1, idActividad);

            rs = ps.executeQuery();

            if (rs.next()) {
                // Descripción y fecha
                boxDescripcion.setText(rs.getString("descripcion"));
                boxFecha.setText(rs.getString("fecha"));

                // Seleccionar cuadrilla en combo
                int idCuadrilla = rs.getInt("idCuadrilla");
                for (int i = 0; i < comboCuadrillaAsignada.getItemCount(); i++) {
                    String item = comboCuadrillaAsignada.getItemAt(i);
                    if (item.startsWith(idCuadrilla + " -")) {
                        comboCuadrillaAsignada.setSelectedIndex(i);
                        break;
                    }
                }

                // Seleccionar colonia en combo
                int idColonia = rs.getInt("idColonia");
                for (int i = 0; i < boxColonia.getItemCount(); i++) {
                    String item = boxColonia.getItemAt(i);
                    if (item.startsWith(idColonia + " -")) {
                        boxColonia.setSelectedIndex(i);
                        break;
                    }
                }

                // Mostrar imagen
                String rutaImagen = rs.getString("evidencia");

                if (rutaImagen != null && !rutaImagen.isEmpty()) {
                    File archivo = new File(rutaImagen);

                    // Si el archivo no existe, intenta con carpeta por defecto
                    if (!archivo.exists()) {
                        String carpetaImagenes = "C:/ruta/a/imagenes/"; // Cambia esta ruta a donde guardas tus imágenes
                        archivo = new File(carpetaImagenes + rutaImagen);
                    }

                    if (archivo.exists()) {
                        ImageIcon icon = new ImageIcon(archivo.getAbsolutePath());
                        Image img = icon.getImage().getScaledInstance(lblImagen.getWidth(), lblImagen.getHeight(), Image.SCALE_SMOOTH);
                        lblImagen.setIcon(new ImageIcon(img));
                        lblImagen.setText(""); // quitar texto
                    } else {
                        lblImagen.setIcon(null);
                        lblImagen.setText("Imagen no encontrada");
                    }
                } else {
                    lblImagen.setIcon(null);
                    lblImagen.setText("Sin imagen");
                }

            } else {
                JOptionPane.showMessageDialog(null, "❌ No se encontró ninguna actividad con ese ID");
                // Limpiar campos si no hay resultado
                boxDescripcion.setText("");
                boxFecha.setText("");
                comboCuadrillaAsignada.setSelectedIndex(-1);
                boxColonia.setSelectedIndex(-1);
                lblImagen.setIcon(null);
                lblImagen.setText("");
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error al buscar la actividad: " + e.getMessage());
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, "Error al cerrar conexión: " + e.getMessage());
            }
        }
    }//GEN-LAST:event_buttonBuscarActionPerformed

    private void buttonEditarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_buttonEditarActionPerformed
        Connection con = null;
        PreparedStatement ps = null;

        try {
            connection conecta = new connection();
            con = conecta.getConexion();

            if (con == null) {
                JOptionPane.showMessageDialog(null, "❌ Error de conexión con la base de datos");
                return;
            }

            String sql = "UPDATE Actividad SET descripcion=?, fecha=?, idCuadrilla=?, idColonia=?, evidencia=? WHERE idActividad=?";
            ps = con.prepareStatement(sql);

            // Obtener valores de los campos
            int idActividad = Integer.parseInt(boxIdActividad.getText());
            String descripcion = boxDescripcion.getText();
            String fechaTexto = boxFecha.getText(); // ejemplo: "2025-04-14"

            // Convertir fecha a java.sql.Date
            java.sql.Date fecha = java.sql.Date.valueOf(fechaTexto); // formato "yyyy-MM-dd"

            // Obtener ID desde combos (formato "1 - Nombre")
            int idCuadrilla = Integer.parseInt(((String) comboCuadrillaAsignada.getSelectedItem()).split(" - ")[0]);
            int idColonia = Integer.parseInt(((String) boxColonia.getSelectedItem()).split(" - ")[0]);

            // Imagen (ruta)
            String imagen = lblImagen.getText();

            // Asignar parámetros
            ps.setString(1, descripcion);
            ps.setDate(2, fecha);
            ps.setInt(3, idCuadrilla);
            ps.setInt(4, idColonia);
            ps.setString(5, imagen);
            ps.setInt(6, idActividad);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                JOptionPane.showMessageDialog(this, "✅ Actividad actualizada correctamente.");
            } else {
                JOptionPane.showMessageDialog(this, "⚠️ No se encontró ninguna actividad con ese ID.");
            }

        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "⚠️ Verifica que los campos numéricos sean correctos.");
        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "❌ Error al actualizar: " + e.getMessage());
        } catch (IllegalArgumentException e) {
            JOptionPane.showMessageDialog(this, "⚠️ La fecha debe tener formato yyyy-MM-dd");
        } finally {
            try {
                if (ps != null) {
                    ps.close();
                }
                if (con != null) {
                    con.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }//GEN-LAST:event_buttonEditarActionPerformed

    private void jButtonSubirImagenActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButtonSubirImagenActionPerformed
        // TODO add your handling code here:
        try {
            // Crear selector de archivos
            JFileChooser fileChooser = new JFileChooser();
            fileChooser.setDialogTitle("Seleccionar imagen de evidencia");

            // Filtro solo para imágenes
            FileNameExtensionFilter filtro = new FileNameExtensionFilter("Imágenes", "jpg", "png", "jpeg", "gif");
            fileChooser.setFileFilter(filtro);

            int seleccion = fileChooser.showOpenDialog(this);

            if (seleccion == JFileChooser.APPROVE_OPTION) {
                // Obtener archivo seleccionado
                File archivo = fileChooser.getSelectedFile();

                // Mostrar la ruta en tu JLabel (por si quieres guardar en BD)
                lblImagen.setText(archivo.getAbsolutePath());

                // Mostrar la imagen visualmente en el JLabel
                ImageIcon icono = new ImageIcon(archivo.getAbsolutePath());
                // Redimensionar para ajustar al JLabel
                Image imagen = icono.getImage().getScaledInstance(lblImagen.getWidth(), lblImagen.getHeight(), Image.SCALE_SMOOTH);
                lblImagen.setIcon(new ImageIcon(imagen));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "❌ Error al subir imagen: " + e.getMessage());
        }
    }//GEN-LAST:event_jButtonSubirImagenActionPerformed

    private void comboCuadrillaAsignadaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboCuadrillaAsignadaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_comboCuadrillaAsignadaActionPerformed

    private void boxColoniaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_boxColoniaActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_boxColoniaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        /* Crear y mostrar el formulario */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Actividades().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JComboBox<String> boxColonia;
    private javax.swing.JTextField boxDescripcion;
    private javax.swing.JTextField boxFecha;
    private javax.swing.JTextField boxIdActividad;
    private java.awt.Button buttonActividades;
    private java.awt.Button buttonBuscar;
    private java.awt.Button buttonColonias;
    private java.awt.Button buttonCuadrillas;
    private java.awt.Button buttonDashboard;
    private java.awt.Button buttonEditar;
    private java.awt.Button buttonEliminar;
    private java.awt.Button buttonGuardar;
    private java.awt.Button buttonNuevo;
    private javax.swing.JComboBox<String> comboCuadrillaAsignada;
    private javax.swing.JButton jButtonMenu;
    private javax.swing.JButton jButtonSubirImagen;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JPanel jPanel3;
    private java.awt.Label label1;
    private java.awt.Label label2;
    private javax.swing.JLabel lblImagen;
    // End of variables declaration//GEN-END:variables
}
